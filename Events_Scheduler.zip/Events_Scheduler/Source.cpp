#include <iostream>
#include "Events.h"
using namespace std;
int main() {
	Events e;
	e.addAt
	e.addAt(0, "mwiun", "wncuiob", "cnwi", 0.21, 102, 22);
	e.addLast("maisra", "ncoiwb", "nqocn", 0.252, 215.01, 0.2);
	e.DeleteAt(0);
	e.isEmpty();
	e.getLength();

	

	return 0;
}

